#!/bin/bash
hdfs dfs -copyToLocal /user/A198663/tamara_key .
chmod 700 ./tamara_key
fecha=${1:-`date +%Y%m%d`}
fichero=BGOU_AUD00001_JR01InteresFondosInversion_${fecha}_${fecha}_1
fechaAyer=$(date --date="yesterday" +"%Y%m%d")
ficheroDiaAnterior=BGOU_AUD00001_JR01InteresFondosInversion_${fechaAyer}_${fechaAyer}_1
ssh -p2153 -i ./tamara_key -o StrictHostKeyChecking=no A198663@sliro5497 << EOT
    kinit -kt A198663.keytab A198663@GRUPO.CM.ES
    rm -f /datos/usuarios/A198663/datos_sfmc/$ficheroDiaAnterior.avro
    rm -f /datos/usuarios/A198663/datos_sfmc/$ficheroDiaAnterior.tkn
    hdfs dfs -copyToLocal /datalab/datalab_bigdata/journeys_oozie/journey_interes_fi/Outgesta/$fichero.avro /datos/usuarios/A198663/datos_sfmc/
    touch /datos/usuarios/A198663/datos_sfmc/$fichero.tkn
     chmod 777 ${fichero}.avro
     chmod 777 ${fichero}.tkn
EOT
rm ./tamara_key

