#!/bin/bash
hdfs dfs -copyToLocal /user/A198663/tamara_key .
chmod 700 ./tamara_key
fecha=${1:-`date +%Y%m%d`}
fechaAyer=$(date --date="yesterday" +"%Y%m%d")
fichero=Core_Contrataciones_${fecha}
ficheroDiaAnterior=Core_Contrataciones_${fechaAyer}
ssh -p2153 -i ./tamara_key -o StrictHostKeyChecking=no A198663@sliro5497 << EOT
     kinit -kt A198663.keytab A198663@GRUPO.CM.ES
     rm -f /datos/usuarios/A198663/datos_sfmc/$ficheroDiaAnterior.csv
     rm -f /datos/usuarios/A198663/datos_sfmc/$ficheroDiaAnterior.tkn
     cd /datos/usuarios/A198663/datos_sfmc/
     hive -f "/datos/usuarios/A198663/hqls/CR04_Datos_Core_Contrataciones_Query_v2.0.hql">${fichero}_aux.txt
     sed "s/NULL//g" ${fichero}_aux.txt> ${fichero}_aux1.txt
     rm -f /datos/usuarios/A198663/datos_sfmc/${fichero}_aux.txt
     perl -lpe 's/"/\\"/g; s/^|$/"/g; s/\t/"|"/g' ${fichero}_aux1.txt > ${fichero}.csv
     rm -f /datos/usuarios/A198663/datos_sfmc/${fichero}_aux1.txt
     touch $fichero.tkn
     chmod 777 ${fichero}.csv
     chmod 777 ${fichero}.tkn
EOT
rm ./tamara_key